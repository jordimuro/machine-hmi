import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import config from '../config/index.js';
import logger from '../config/logger.js';
import tagStore from '../stores/tagStore.js';
import alarmStore from '../stores/alarmStore.js';
import historyStore from '../stores/historyStore.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * OPC UA Client Manager
 * Handles connection, polling, and writing to OPC UA server
 * Falls back to mockup mode if real OPC UA is not available
 */
class OpcuaClient {
  constructor() {
    this.connected = false;
    this.tagsConfig = null;
    this.pollingInterval = null;
    this.loggingInterval = null;
    this.mockMode = false;
    this.mockData = {};
    this.reconnectTimer = null;
    this.reconnectAttempts = 0;
    this.maxReconnectDelay = 60000; // 60 seconds
  }

  /**
   * Initialize the OPC UA client
   */
  async init() {
    try {
      // Load tags configuration
      const tagsConfigPath = join(__dirname, '../../tags.json');
      this.tagsConfig = JSON.parse(readFileSync(tagsConfigPath, 'utf8'));

      logger.info({ tagsCount: Object.keys(this.tagsConfig.tags).length }, 'Tags configuration loaded');

      // Try to connect to real OPC UA server
      await this.connect();
    } catch (error) {
      logger.error({ err: error }, 'Failed to initialize OPC UA client');
      throw error;
    }
  }

  /**
   * Connect to OPC UA server with fallback to mock mode
   */
  async connect() {
    try {
      // Try to import node-opcua
      const opcua = await import('node-opcua');

      logger.info({ endpoint: config.opcua.endpoint }, 'Attempting to connect to OPC UA server');

      // Try real OPC UA connection
      await this.connectReal(opcua);

    } catch (error) {
      logger.warn({ err: error }, 'node-opcua not available or connection failed, using mock mode');
      this.enableMockMode();
    }
  }

  /**
   * Connect to real OPC UA server
   */
  async connectReal(opcua) {
    try {
      // Create OPC UA client
      this.client = opcua.OPCUAClient.create({
        applicationName: "Machine HMI Client",
        connectionStrategy: {
          initialDelay: 1000,
          maxRetry: 3
        },
        securityMode: opcua.MessageSecurityMode.None,
        securityPolicy: opcua.SecurityPolicy.None,
        endpoint_must_exist: false
      });

      // Connect to server
      await this.client.connect(config.opcua.endpoint);
      logger.info('Connected to OPC UA server');

      // Create session
      this.session = await this.client.createSession();
      logger.info('OPC UA session created');

      this.connected = true;
      this.mockMode = false;
      this.reconnectAttempts = 0;

      // Notify WebSocket clients of status change
      this.notifyStatusChange();

      // Initialize tag store with initial values
      await this.readAllTags();

      // Start polling and logging
      this.startPolling();
      this.startLogging();

    } catch (error) {
      logger.error({ err: error }, 'Failed to connect to real OPC UA server');
      this.connected = false;
      this.notifyStatusChange();
      throw error;
    }
  }

  /**
   * Read all tags from OPC UA server
   */
  async readAllTags() {
    if (!this.session) return;

    const nodeIds = Object.entries(this.tagsConfig.tags).map(([tagName, tagConfig]) => ({
      tagName,
      nodeId: tagConfig.nodeId
    }));

    try {
      const nodesToRead = nodeIds.map(({ nodeId }) => ({
        nodeId: nodeId,
        attributeId: 13 // Value attribute
      }));

      const dataValues = await this.session.read(nodesToRead);

      dataValues.forEach((dataValue, index) => {
        const { tagName } = nodeIds[index];
        
        if (dataValue.statusCode.isGood()) {
          const value = dataValue.value.value;
          tagStore.update(tagName, value, 'good');
          logger.debug({ tagName, value }, 'Tag read successfully');
        } else {
          tagStore.update(tagName, null, 'bad');
          logger.warn({ tagName, statusCode: dataValue.statusCode.toString() }, 'Tag read failed');
        }
      });

    } catch (error) {
      logger.error({ err: error }, 'Failed to read tags from OPC UA server');
    }
  }

  /**
   * Enable mock mode for testing without real PLC
   */
  enableMockMode() {
    this.mockMode = true;
    this.connected = true;

    // Initialize mock data
    Object.entries(this.tagsConfig.tags).forEach(([tagName, tagConfig]) => {
      if (tagConfig.type === 'boolean') {
        this.mockData[tagName] = false;
      } else if (tagConfig.type === 'number') {
        const min = tagConfig.min || 0;
        const max = tagConfig.max || 100;
        this.mockData[tagName] = min + (max - min) * 0.5; // Start at middle
      } else {
        this.mockData[tagName] = '';
      }

      // Initialize tag store
      tagStore.update(tagName, this.mockData[tagName], 'good');
    });

    logger.info('Mock OPC UA mode enabled with simulated data');

    // Start polling and logging
    this.startPolling();
    this.startLogging();
  }

  /**
   * Start polling tags
   */
  startPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
    }

    const pollingRate = this.tagsConfig.pollingRateMs || config.opcua.pollingRateMs;

    this.pollingInterval = setInterval(() => {
      this.pollTags();
    }, pollingRate);

    logger.info({ pollingRateMs: pollingRate }, 'Started tag polling');
  }

  /**
   * Poll all tags
   */
  pollTags() {
    if (!this.connected) {
      return;
    }

    if (this.mockMode) {
      this.pollTagsMock();
    } else {
      this.pollTagsReal();
    }
  }

  /**
   * Poll tags from real OPC UA server
   */
  async pollTagsReal() {
    if (!this.session) return;

    try {
      await this.readAllTags();
    } catch (error) {
      logger.error({ err: error }, 'Error polling tags from OPC UA server');
      
      // If connection lost, try to reconnect
      if (error.message.includes('BadConnectionClosed') || error.message.includes('ECONNRESET')) {
        logger.warn('Connection lost, attempting to reconnect...');
        this.connected = false;
        this.scheduleReconnect();
      }
    }
  }

  /**
   * Poll tags in mock mode with simulated realistic data
   */
  pollTagsMock() {
    Object.entries(this.tagsConfig.tags).forEach(([tagName, tagConfig]) => {
      let newValue = this.mockData[tagName];

      if (tagConfig.type === 'boolean') {
        // Randomly flip booleans occasionally
        if (Math.random() < 0.02) { // 2% chance per poll
          newValue = !newValue;
          this.mockData[tagName] = newValue;
        }
      } else if (tagConfig.type === 'number') {
        // Add realistic variation to numbers
        const min = tagConfig.min || 0;
        const max = tagConfig.max || 100;
        const variation = (max - min) * 0.02; // 2% variation

        // Random walk
        newValue += (Math.random() - 0.5) * variation;
        newValue = Math.max(min, Math.min(max, newValue));

        // Simulate production count incrementing
        if (tagName === 'ProductionCount' && this.mockData['MachineRunning']) {
          newValue = Math.floor(newValue + Math.random() * 0.5);
        }

        this.mockData[tagName] = newValue;
      }

      // Update tag store
      tagStore.update(tagName, newValue, 'good');

      // Handle alarm tags
      if (tagConfig.alarm) {
        alarmStore.setAlarm(tagName, newValue === true, tagConfig.message || '');
      }
    });

    // Simulate occasional alarms
    this.simulateAlarms();
  }

  /**
   * Simulate alarms based on process values
   */
  simulateAlarms() {
    const temp1 = this.mockData['TemperatureZone1'];
    const temp2 = this.mockData['TemperatureZone2'];
    const pressure = this.mockData['Pressure'];

    // Temperature alarm
    if (temp1 > 250 || temp2 > 250) {
      if (!this.mockData['Alarm_Overtemp']) {
        this.mockData['Alarm_Overtemp'] = true;
        tagStore.update('Alarm_Overtemp', true, 'good');
        alarmStore.setAlarm('Alarm_Overtemp', true, 'Temperature exceeded safety limit');
      }
    } else {
      if (this.mockData['Alarm_Overtemp']) {
        this.mockData['Alarm_Overtemp'] = false;
        tagStore.update('Alarm_Overtemp', false, 'good');
        alarmStore.setAlarm('Alarm_Overtemp', false, '');
      }
    }

    // Pressure alarm
    if (pressure > 8) {
      if (!this.mockData['Alarm_OverPressure']) {
        this.mockData['Alarm_OverPressure'] = true;
        tagStore.update('Alarm_OverPressure', true, 'good');
        alarmStore.setAlarm('Alarm_OverPressure', true, 'Pressure exceeded safety limit');
      }
    } else {
      if (this.mockData['Alarm_OverPressure']) {
        this.mockData['Alarm_OverPressure'] = false;
        tagStore.update('Alarm_OverPressure', false, 'good');
        alarmStore.setAlarm('Alarm_OverPressure', false, '');
      }
    }
  }

  /**
   * Start periodic logging of loggable tags
   */
  startLogging() {
    if (this.loggingInterval) {
      clearInterval(this.loggingInterval);
    }

    this.loggingInterval = setInterval(() => {
      this.logTags();
    }, config.logging.logIntervalMs);

    logger.info({ logIntervalMs: config.logging.logIntervalMs }, 'Started tag logging');
  }

  /**
   * Log loggable tags to history
   */
  logTags() {
    const loggableTags = Object.entries(this.tagsConfig.tags)
      .filter(([_, tagConfig]) => tagConfig.loggable)
      .map(([tagName, _]) => tagStore.get(tagName))
      .filter(tag => tag !== undefined);

    if (loggableTags.length > 0) {
      historyStore.logTags(loggableTags);
    }
  }

  /**
   * Write a value to a tag
   */
  async writeTag(tagName, value) {
    const tagConfig = this.tagsConfig.tags[tagName];

    if (!tagConfig) {
      throw new Error(`Tag ${tagName} not found in configuration`);
    }

    if (!tagConfig.writable) {
      throw new Error(`Tag ${tagName} is not writable`);
    }

    // Validate value range
    if (tagConfig.type === 'number') {
      if (tagConfig.min !== undefined && value < tagConfig.min) {
        throw new Error(`Value ${value} below minimum ${tagConfig.min}`);
      }
      if (tagConfig.max !== undefined && value > tagConfig.max) {
        throw new Error(`Value ${value} above maximum ${tagConfig.max}`);
      }
    }

    if (this.mockMode) {
      // Write to mock data
      this.mockData[tagName] = value;
      tagStore.update(tagName, value, 'good');
      logger.info({ tagName, value }, 'Tag written (mock mode)');
      return true;
    } else {
      // Implement real OPC UA write here
      throw new Error('Real OPC UA write not yet implemented');
    }
  }

  /**
   * Execute a command
   */
  async executeCommand(command, params = {}) {
    logger.info({ command, params }, 'Executing command');

    switch (command) {
      case 'START':
        if (this.mockMode) {
          this.mockData['MachineRunning'] = true;
          tagStore.update('MachineRunning', true, 'good');
          logger.info('Machine started (mock mode)');
        }
        break;

      case 'STOP':
        if (this.mockMode) {
          this.mockData['MachineRunning'] = false;
          tagStore.update('MachineRunning', false, 'good');
          logger.info('Machine stopped (mock mode)');
        }
        break;

      case 'RESET_ALARMS':
        alarmStore.clearAll();
        if (this.mockMode) {
          // Reset all alarm tags
          Object.entries(this.tagsConfig.tags).forEach(([tagName, tagConfig]) => {
            if (tagConfig.alarm) {
              this.mockData[tagName] = false;
              tagStore.update(tagName, false, 'good');
            }
          });
        }
        logger.info('Alarms reset');
        break;

      case 'SET_SETPOINT':
        if (params.tag && params.value !== undefined) {
          await this.writeTag(params.tag, params.value);
        } else {
          throw new Error('SET_SETPOINT requires tag and value parameters');
        }
        break;

      default:
        throw new Error(`Unknown command: ${command}`);
    }

    return { success: true, command, params };
  }

  /**
   * Schedule reconnection attempt
   */
  scheduleReconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }

    const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), this.maxReconnectDelay);
    this.reconnectAttempts++;

    logger.info({ delay, attempt: this.reconnectAttempts }, 'Scheduling reconnection attempt');

    this.reconnectTimer = setTimeout(async () => {
      try {
        await this.connect();
      } catch (error) {
        logger.error({ err: error }, 'Reconnection attempt failed');
        this.scheduleReconnect();
      }
    }, delay);
  }

  /**
   * Browse OPC UA server nodes with hierarchical navigation
   */
  async browseNodes(nodeId = 'RootFolder', options = {}) {
    if (!this.session || this.mockMode) {
      return { error: 'No active OPC UA session or in mock mode' };
    }

    const {
      recursive = true,
      maxDepth = 5,
      currentDepth = 0,
      includeObjects = true,
      variablesOnly = false,
      expandArrays = false
    } = options;

    try {
      const browseResult = await this.session.browse(nodeId);
      const nodes = [];
      const variables = [];

      if (browseResult.references) {
        for (const ref of browseResult.references) {
          const node = {
            nodeId: ref.nodeId.toString(),
            browseName: ref.browseName.toString(),
            displayName: ref.displayName?.text || ref.browseName.toString(),
            nodeClass: ref.nodeClass,
            typeDefinition: ref.typeDefinition?.toString(),
            isVariable: ref.nodeClass === 2, // NodeClass.Variable = 2
            isObject: ref.nodeClass === 1,   // NodeClass.Object = 1
            depth: currentDepth,
            path: this.buildNodePath(nodeId, ref.browseName.toString())
          };

          // Si es una variable, obtener información adicional
          if (node.isVariable) {
            try {
              const dataValue = await this.session.readVariableValue(ref.nodeId);
              node.dataType = this.getDataTypeName(dataValue.dataType);
              node.value = dataValue.value?.value;
              node.quality = dataValue.statusCode?.name || 'Unknown';
              node.accessible = true;
              variables.push(node);
            } catch (readError) {
              node.accessible = false;
              node.error = readError.message;
              // Aún agregar variables no accesibles para mostrar en la UI
              variables.push(node);
            }
          }

          // Agregar nodos según las opciones
          if (!variablesOnly || node.isVariable) {
            nodes.push(node);
          }

          // Explorar recursivamente objetos si no hemos alcanzado la profundidad máxima
          if (recursive && currentDepth < maxDepth && node.isObject) {
            try {
              const childResult = await this.browseNodes(
                ref.nodeId.toString(), 
                { ...options, currentDepth: currentDepth + 1 }
              );
              if (childResult.nodes) {
                nodes.push(...childResult.nodes);
                variables.push(...childResult.variables || []);
              }
            } catch (childError) {
              logger.warn({ err: childError, nodeId: ref.nodeId.toString() }, 'Failed to browse child nodes');
            }
          }
        }
      }

      return { 
        nodes: variablesOnly ? variables : nodes,
        variables,
        count: variablesOnly ? variables.length : nodes.length,
        variableCount: variables.length,
        totalScanned: nodes.length,
        depth: currentDepth
      };
    } catch (error) {
      logger.error({ err: error, nodeId }, 'Failed to browse nodes');
      return { error: error.message };
    }
  }

  /**
   * Browse specifically for CODESYS Application variables with array expansion
   */
  async browseApplicationVariables() {
    const commonPaths = [
      'ns=4;s=|var|CODESYS Control for Raspberry Pi SL.Application',
      'ns=4;s=Application'
    ];

    let allVariables = [];

    // Intentar diferentes rutas comunes para CODESYS
    for (const path of commonPaths) {
      try {
        const result = await this.browseNodes(path, { 
          recursive: true, 
          maxDepth: 4, 
          variablesOnly: true,
          expandArrays: true
        });
        
        if (result.variables && result.variables.length > 0) {
          allVariables.push(...result.variables);
        }
      } catch (error) {
        logger.debug({ path, err: error }, 'Failed to browse path');
      }
    }

    // Si no encontramos variables en rutas específicas, hacer búsqueda general
    if (allVariables.length === 0) {
      try {
        const result = await this.browseNodes('RootFolder', { 
          recursive: true, 
          maxDepth: 6, 
          variablesOnly: true,
          expandArrays: true
        });
        allVariables = result.variables || [];
      } catch (error) {
        logger.error({ err: error }, 'Failed general browse');
      }
    }

    // Expandir arrays manualmente si no se expandieron automáticamente
    const expandedVariables = [];
    for (const variable of allVariables) {
      expandedVariables.push(variable);
      
      // Si es un array, intentar expandir sus elementos
      if (this.isArrayVariable(variable)) {
        const arrayElements = await this.expandArrayVariable(variable);
        expandedVariables.push(...arrayElements);
      }
    }

    // Filtrar variables que parecen ser de aplicación
    const applicationVariables = expandedVariables.filter(variable => {
      const nodeId = variable.nodeId.toLowerCase();
      const displayName = variable.displayName.toLowerCase();
      
      return nodeId.includes('application') || 
             nodeId.includes('gvl') ||
             displayName.includes('actualspeed') ||
             displayName.includes('randomvalues') ||
             displayName.includes('[') || // Elementos de array
             variable.accessible;
    });

    return {
      nodes: applicationVariables,
      variables: applicationVariables,
      count: applicationVariables.length,
      totalScanned: expandedVariables.length
    };
  }

  /**
   * Check if a variable is an array
   */
  isArrayVariable(variable) {
    return variable.displayName.toLowerCase().includes('randomvalues') && 
           !variable.displayName.includes('[');
  }

  /**
   * Expand array variable to show individual elements
   */
  async expandArrayVariable(arrayVariable) {
    const elements = [];
    const baseName = arrayVariable.displayName;
    const baseNodeId = arrayVariable.nodeId;
    
    // Para RandomValues, intentar expandir elementos del 1 al 20
    if (baseName.toLowerCase().includes('randomvalues')) {
      for (let i = 1; i <= 20; i++) {
        try {
          const elementNodeId = `${baseNodeId}[${i}]`;
          
          // Intentar leer el valor del elemento
          const dataValue = await this.session.readVariableValue(elementNodeId);
          
          elements.push({
            nodeId: elementNodeId,
            browseName: `${baseName}[${i}]`,
            displayName: `${baseName}[${i}]`,
            nodeClass: 2, // Variable
            isVariable: true,
            isArrayElement: true,
            arrayIndex: i,
            parentArray: baseName,
            dataType: this.getDataTypeName(dataValue.dataType),
            value: dataValue.value?.value,
            quality: dataValue.statusCode?.name || 'Unknown',
            accessible: true,
            depth: (arrayVariable.depth || 0) + 1,
            path: `${arrayVariable.path || baseName}[${i}]`
          });
        } catch (error) {
          // Si no se puede leer, aún agregar el elemento como no accesible
          elements.push({
            nodeId: `${baseNodeId}[${i}]`,
            browseName: `${baseName}[${i}]`,
            displayName: `${baseName}[${i}]`,
            nodeClass: 2,
            isVariable: true,
            isArrayElement: true,
            arrayIndex: i,
            parentArray: baseName,
            accessible: false,
            error: error.message,
            depth: (arrayVariable.depth || 0) + 1,
            path: `${arrayVariable.path || baseName}[${i}]`
          });
        }
      }
    }
    
    return elements;
  }

  /**
   * Build a readable path for a node
   */
  buildNodePath(parentNodeId, browseName) {
    if (parentNodeId === 'RootFolder') {
      return browseName;
    }
    
    // Simplificar el path para mostrar solo la parte relevante
    const parts = parentNodeId.split('.');
    const lastPart = parts[parts.length - 1] || parentNodeId;
    return `${lastPart}.${browseName}`;
  }

  /**
   * Get human-readable data type name
   */
  getDataTypeName(dataType) {
    if (!dataType) return 'Unknown';
    
    const typeMap = {
      1: 'Boolean',
      2: 'SByte', 
      3: 'Byte',
      4: 'Int16',
      5: 'UInt16', 
      6: 'Int32',
      7: 'UInt32',
      8: 'Int64',
      9: 'UInt64',
      10: 'Float',
      11: 'Double',
      12: 'String',
      13: 'DateTime',
      15: 'Guid',
      22: 'Structure'
    };

    return typeMap[dataType] || `DataType_${dataType}`;
  }

  /**
   * Add new variables to monitoring dynamically
   */
  async addVariables(newVariables) {
    const added = [];
    const skipped = [];

    for (const variable of newVariables) {
      try {
        // Generar un nombre único para la variable
        const tagName = this.generateTagName(variable.displayName, variable.nodeId);
        
        // Verificar si ya existe
        if (this.tagsConfig.tags[tagName]) {
          skipped.push({ variable, reason: 'Already exists' });
          continue;
        }

        // Crear configuración del tag
        const tagConfig = {
          nodeId: variable.nodeId,
          loggable: true,
          type: this.mapDataType(variable.dataType),
          description: variable.displayName,
          unit: this.inferUnit(variable.displayName),
          accessible: variable.accessible
        };

        // Agregar al mapa de configuración
        this.tagsConfig.tags[tagName] = tagConfig;
        
        // Inicializar el valor del tag
        this.tags.set(tagName, {
          name: tagName,
          value: null,
          quality: 'uncertain',
          timestamp: Date.now(),
          ...tagConfig
        });

        added.push({ tagName, variable, config: tagConfig });
        
        logger.info({ tagName, nodeId: variable.nodeId }, 'Added new variable to monitoring');
      } catch (error) {
        skipped.push({ variable, reason: error.message });
        logger.warn({ err: error, variable }, 'Failed to add variable');
      }
    }

    // Guardar la configuración actualizada
    if (added.length > 0) {
      await this.saveTagsConfiguration();
    }

    return { added, skipped };
  }

  /**
   * Generate a unique tag name from display name and node ID
   */
  generateTagName(displayName, nodeId) {
    // Limpiar el nombre para que sea válido como identificador
    let tagName = displayName
      .replace(/[^a-zA-Z0-9_]/g, '_')
      .replace(/_{2,}/g, '_')
      .replace(/^_|_$/g, '');
    
    // Si el nombre está vacío o es muy corto, usar parte del nodeId
    if (tagName.length < 3) {
      const nodeIdPart = nodeId.split('.').pop() || nodeId.split('=').pop() || 'Variable';
      tagName = nodeIdPart.replace(/[^a-zA-Z0-9_]/g, '_');
    }

    // Asegurar que sea único
    let uniqueName = tagName;
    let counter = 1;
    while (this.tagsConfig.tags[uniqueName]) {
      uniqueName = `${tagName}_${counter}`;
      counter++;
    }

    return uniqueName;
  }

  /**
   * Map OPC UA data type to internal type
   */
  mapDataType(opcuaDataType) {
    if (!opcuaDataType) return 'unknown';
    
    const typeStr = opcuaDataType.toLowerCase();
    if (typeStr.includes('bool')) return 'boolean';
    if (typeStr.includes('int') || typeStr.includes('real') || typeStr.includes('double') || typeStr.includes('float')) return 'number';
    if (typeStr.includes('string')) return 'string';
    return 'unknown';
  }

  /**
   * Infer unit from variable name
   */
  inferUnit(displayName) {
    const name = displayName.toLowerCase();
    if (name.includes('temp')) return '°C';
    if (name.includes('speed') || name.includes('rpm')) return 'RPM';
    if (name.includes('pressure')) return 'bar';
    if (name.includes('count') || name.includes('counter')) return 'units';
    if (name.includes('percent') || name.includes('%')) return '%';
    return '';
  }

  /**
   * Save tags configuration to file
   */
  async saveTagsConfiguration() {
    try {
      const fs = await import('fs/promises');
      const path = await import('path');
      const configPath = path.join(process.cwd(), 'tags.json');
      
      await fs.writeFile(configPath, JSON.stringify(this.tagsConfig, null, 2));
      logger.info('Tags configuration saved successfully');
    } catch (error) {
      logger.error({ err: error }, 'Failed to save tags configuration');
      throw error;
    }
  }

  /**
   * Get connection status
   */
  getStatus() {
    return {
      connected: this.connected,
      mockMode: this.mockMode,
      endpoint: config.opcua.endpoint,
      tagsCount: Object.keys(this.tagsConfig?.tags || {}).length,
      reconnectAttempts: this.reconnectAttempts
    };
  }

  /**
   * Notify WebSocket clients of status change
   */
  notifyStatusChange() {
    // Use setTimeout to avoid circular dependency issues
    setTimeout(() => {
      try {
        // Import wsHandler dynamically
        import('../websocket/wsHandler.js').then(({ default: wsHandler }) => {
          const status = this.getStatus();
          wsHandler.broadcastOpcuaStatus(status);
        }).catch(() => {
          // Ignore import errors
        });
      } catch (error) {
        // Ignore errors if wsHandler is not available yet
        logger.debug({ err: error }, 'Could not notify WebSocket clients of status change');
      }
    }, 100);
  }

  /**
   * Disconnect and cleanup
   */
  async disconnect() {
    logger.info('Disconnecting OPC UA client');

    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }

    if (this.loggingInterval) {
      clearInterval(this.loggingInterval);
      this.loggingInterval = null;
    }

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    // Close OPC UA session and client
    try {
      if (this.session) {
        await this.session.close();
        this.session = null;
      }
      
      if (this.client) {
        await this.client.disconnect();
        this.client = null;
      }
    } catch (error) {
      logger.warn({ err: error }, 'Error during OPC UA cleanup');
    }

    this.connected = false;

    // Set all tags to bad quality
    tagStore.setAllQuality('bad');

    logger.info('OPC UA client disconnected');
  }
}

// Singleton instance
const opcuaClient = new OpcuaClient();

export default opcuaClient;
